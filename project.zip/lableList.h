//
// Created by ronia on 30/07/2021.
//

#ifndef RONIPROJECT_LABLELIST_H
#define RONIPROJECT_LABLELIST_H

#include "default.h"
void addLabelToList(labelListPtr *, labelListPtr );
int labelNameCompare(labelListPtr *head, labelListPtr labelToAdd);

#endif //RONIPROJECT_LABLELIST_H
